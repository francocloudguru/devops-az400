﻿namespace webapp.Modules
{
    public class Functions
    {
        public int Add(int x, int y)
        {
            return x + y;
        }
    }
}
